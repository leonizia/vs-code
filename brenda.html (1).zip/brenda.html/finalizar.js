
    // Preencher informações do usuário
    const user = JSON.parse(localStorage.getItem("user"));
    if (user) {
      document.getElementById("user-name").textContent = user.name;
      document.getElementById("user-email").textContent = user.email;
      document.getElementById("user-phone").textContent = user.phone;
      if (user.photo) {
        document.getElementById("user-photo").src = user.photo;
      }
    }
       // Mostrar itens do carrinho
    const carrinho = JSON.parse(localStorage.getItem("carrinhoItens")) || [];
    const total = localStorage.getItem("carrinhoTotal") || "0.00";
    const lista = document.getElementById("cart-items");
    const totalSpan = document.getElementById("cart-total");

    carrinho.forEach(item => {
      const li = document.createElement("li");
      li.innerHTML = `
        <strong>${item.nome}</strong> - R$${item.preco.toFixed(2)} x ${item.qtd}
      `;
      lista.appendChild(li);
    });

    totalSpan.textContent = parseFloat(total).toFixed(2);

    // Mostrar opções de pagamento
    const metodoPagamento = document.getElementById("payment-method");
    const pixDiv = document.getElementById("pix-key");
    const trocoDiv = document.getElementById("troco-field");

    metodoPagamento.addEventListener("change", () => {
      pixDiv.style.display = metodoPagamento.value === "pix" ? "block" : "none";
      trocoDiv.style.display = metodoPagamento.value === "dinheiro" ? "block" : "none";
    });

    // Finalizar compra
    document.getElementById("finalizar-compra").addEventListener("click", () => {
      document.getElementById("checkout-container").style.display = "none";
      document.getElementById("thank-you").style.display = "block";
      // Limpar carrinho
      localStorage.removeItem("carrinhoItens");
      localStorage.removeItem("carrinhoTotal");
    });
    document.getElementById("cart-total").textContent = total.toFixed(2);

    // CEP com formatação
    document.getElementById("cep").addEventListener("input", function() {
      let v = this.value.replace(/\D/g, "");
      if (v.length > 5) {
        this.value = v.slice(0, 5) + "-" + v.slice(5, 8);
      } else {
        this.value = v;
      }
    });

    // Opções de pagamento
    document.getElementById("payment-method").addEventListener("change", function() {
      const pixDiv = document.getElementById("pix-key");
      const trocoDiv = document.getElementById("troco-field");

      pixDiv.style.display = this.value === "pix" ? "block" : "none";
      trocoDiv.style.display = this.value === "dinheiro" ? "block" : "none";
    });

    // Finalizar compra
    document.getElementById("finalizar-compra").addEventListener("click", function() {
      document.getElementById("checkout-container").style.display = "none";
      document.getElementById("thank-you").style.display = "block";
    });
