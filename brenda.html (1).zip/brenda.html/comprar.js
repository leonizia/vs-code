function filterProdutos() {
  var input = document.getElementById('pesquisarinput').value.toUpperCase();
  var produtos = document.getElementsByClassName('produtos');
  for (var i = 0; i < produtos.length; i++) {
    var h3 = produtos[i].getElementsByTagName('h3')[0];
    if (h3.innerHTML.toUpperCase().indexOf(input) > -1 || input === '') {
      produtos[i].style.display = '';
    } else {
      produtos[i].style.display = 'none';
    }
  }
}
let total = 0;
let contador = 0;

const botoesComprar = document.querySelectorAll('.comprar-button');
const listaCarrinho = document.getElementById('itens-carrinho');
const totalSpan = document.getElementById('total');
const contadorItens = document.getElementById('contador-itens');

botoesComprar.forEach(botao => {
  botao.addEventListener('click', () => {
    const produto = botao.closest('.produtos');
    const nome = produto.querySelector('h3').innerText;
    const preco = parseFloat(produto.querySelector('.produtos-info p').innerText.replace('R$', '').replace(',', '.'));
    const imgSrc = produto.querySelector('img').src;

    const itemExistente = [...listaCarrinho.children].find(el => el.querySelector('h4').innerText === nome);

    if (itemExistente) {
      const qtdEl = itemExistente.querySelector('.quantidade');
      qtdEl.textContent = parseInt(qtdEl.textContent) + 1;
    } else {
      const item = document.createElement('div');
      item.style.display = "flex";
      item.style.alignItems = "center";
      item.style.marginBottom = "10px";

      item.innerHTML = `
        <img src="${imgSrc}" style="width: 50px; height: 50px; object-fit: cover; margin-right: 10px;">
        <div style="flex: 1;">
          <h4>${nome}</h4>
          <p>R$${preco.toFixed(2)}</p>
          <div>
            <button class="menos">-</button>
            <span class="quantidade">1</span>
            <button class="mais">+</button>
            <button class="remover">🗑</button>
          </div>
        </div>
      `;

      listaCarrinho.appendChild(item);

      item.querySelector('.mais').onclick = () => {
        const qtd = item.querySelector('.quantidade');
        qtd.textContent = parseInt(qtd.textContent) + 1;
        atualizarTotal();
      };

      item.querySelector('.menos').onclick = () => {
        const qtd = item.querySelector('.quantidade');
        let q = parseInt(qtd.textContent);
        if (q > 1) {
          qtd.textContent = q - 1;
        } else {
          item.remove();
        }
        atualizarTotal();
      };

      item.querySelector('.remover').onclick = () => {
        item.remove();
        atualizarTotal();
      };
    }

    atualizarTotal();
  });
});

function atualizarTotal() {
  let total = 0;
  let count = 0;
  [...listaCarrinho.children].forEach(item => {
    const preco = parseFloat(item.querySelector('p').innerText.replace('R$', ''));
    const qtd = parseInt(item.querySelector('.quantidade').textContent);
    total += preco * qtd;
    count += qtd;
  });
  totalSpan.textContent = total.toFixed(2);
  contadorItens.textContent = count;
}

// Abrir e fechar o carrinho
document.getElementById('abrir-carrinho').onclick = () => {
  const carrinho = document.getElementById('carrinho');
  carrinho.style.display = carrinho.style.display === 'none' ? 'block' : 'none';
};


// Botão finalizar
document.getElementById('finalizar').onclick = () => {
  window.location.href = "cadastro.html";
};
document.getElementById('botinicio').onclick = () => {
  window.location.href = "inicio.html";
};
document.getElementById('voucher').onclick = () => {
  window.location.href = "menu.html";
};
//-----------------luana-------------------------------------
atualizarTotal(); // Atualiza o valor total e salva no localStorage
// Função que calcula o total do carrinho e salva no localStorage
function atualizarTotal() {
  let total = 0;
  let count = 0;
  const itens = [];

  [...listaCarrinho.children].forEach(item => {
    const nome = item.querySelector('h4').innerText;
    const preco = parseFloat(item.querySelector('p').innerText.replace('R$', '').replace(',', '.'));
    const qtd = parseInt(item.querySelector('.quantidade').textContent);
    const img = item.querySelector('img').src;

    total += preco * qtd;
    count += qtd;

    // Armazena os dados do item em um array para salvar no localStorage
    itens.push({ nome, preco, qtd, img });
  });

  // Atualiza o total e a contagem na tela
  totalSpan.textContent = total.toFixed(2);
  contadorItens.textContent = count;

  // Salva os dados no localStorage
  localStorage.setItem('carrinhoItens', JSON.stringify(itens));
  localStorage.setItem('carrinhoTotal', total.toFixed(2));
}

// Botão para abrir ou fechar o carrinho
document.getElementById('abrir-carrinho').onclick = () => {
  const carrinho = document.getElementById('carrinho');
  carrinho.style.display = carrinho.style.display === 'none' ? 'block' : 'none';
};

// Botão de finalizar compra (leva para a página doceria.html)
document.getElementById('finalizar').addEventListener('click', function() {
    window.location.href = 'cadastro.html';
});

// Botão de voltar para a página inicial
document.getElementById('botinicio').onclick = () => {
  window.location.href = "inicio.html";
};

// Botão de ir para o menu
document.getElementById('menu').onclick = () => {
  window.location.href = "menu.html";
};