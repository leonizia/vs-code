// Botões de alternância entre login e cadastro
document.querySelector("#signin").addEventListener("click", () => {
  // Altera a classe do body para exibir o formulário de login
  document.body.className = "sign-in-js";
});

document.querySelector("#signup").addEventListener("click", () => {
  // Altera a classe do body para exibir o formulário de cadastro
  document.body.className = "sign-up-js";
});

// Evento de envio do formulário de cadastro
document.getElementById("signup-form").addEventListener("submit", function(e) {
  // Impede que a página recarregue ao enviar o formulário
  e.preventDefault();

  // Coleta os dados preenchidos pelo usuário no formulário de cadastro
  const name = document.getElementById("signup-name").value;
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;
  const phone = document.getElementById("signup-phone").value;
  const photoInput = document.getElementById("signup-photo"); // Campo de envio de imagem
  const reader = new FileReader(); // Objeto para ler arquivos (como imagens)

  // Verifica se o usuário enviou uma foto
  if (photoInput.files[0]) {
    // Quando o arquivo terminar de ser lido
    reader.onload = function(event) {
      // Converte a imagem em base64
      const photoBase64 = event.target.result;

      // Salva os dados do usuário, incluindo a foto
      saveUser({ name, email, password, phone, photo: photoBase64 });
    };

    // Lê o arquivo como URL de dados (base64)
    reader.readAsDataURL(photoInput.files[0]);
  } else {
    // Caso não tenha foto, salva os outros dados
    saveUser({ name, email, password, phone });
  }
});

// Função que salva os dados do usuário no localStorage
function saveUser(user) {
  // Salva os dados do usuário convertidos em texto JSON
  localStorage.setItem("user", JSON.stringify(user));

  // Marca o usuário como "logado"
  localStorage.setItem("loggedIn", "true");

  // Redireciona para a página anterior ou padrão após login/cadastro
  redirectAfterLogin();
}

// Evento de envio do formulário de login
document.getElementById("signin-form").addEventListener("submit", function(e) {
  // Impede o comportamento padrão do formulário (recarregar a página)
  e.preventDefault();

  // Pega os valores digitados pelo usuário nos campos de login
  const email = document.getElementById("signin-email").value;
  const password = document.getElementById("signin-password").value;

  // Recupera os dados salvos do usuário
  const savedUser = JSON.parse(localStorage.getItem("user"));

  // Verifica se o email e senha digitados coincidem com os salvos
  if (savedUser && email === savedUser.email && password === savedUser.password) {
    // Marca como logado
    localStorage.setItem("loggedIn", "true");

    // Redireciona para a página anterior ou padrão
    redirectAfterLogin();
  } else {
    // Alerta de erro caso os dados estejam incorretos
    alert("Usuário ou senha incorretos!");
  }
});

// Função que redireciona o usuário após login ou cadastro
function redirectAfterLogin() {
  // Pega a última página salva ou usa "finalizar.html" como padrão
  const lastPage = localStorage.getItem("lastPage") || "finalizar.html";

  // Redireciona o usuário para essa página
  window.location.href = lastPage;
}

// Evento que é executado assim que a página de login/cadastro é carregada
document.addEventListener("DOMContentLoaded", function() {
  // Obtém a URL da página anterior
  const from = document.referrer;

  // Se a página anterior não for a própria de login ou cadastro, salva como última página
  if (from && !from.includes("login") && !from.includes("cadastro")) {
    localStorage.setItem("lastPage", from);
  }
});