document.addEventListener('DOMContentLoaded', () => {
    // 1. Gerar QR Code
    const qrcodeContainer = document.getElementById('qrcode');
    const currentUrl = window.location.href; // Pega a URL atual da página

    if (qrcodeContainer) {
        new QRCode(qrcodeContainer, {
            text: currentUrl, // O QR Code vai levar para a URL atual do menu
            width: 200,
            height: 200,
            colorDark: "#D12B7E", // Cor escura do QR Code
            colorLight: "#ffffff", // Cor clara do QR Code
            correctLevel: QRCode.CorrectLevel.H // Nível de correção de erro
        });
    }

    // 2. Gerar PDF
    const downloadPdfBtn = document.getElementById('downloadPdfBtn');

    if (downloadPdfBtn) {
        downloadPdfBtn.addEventListener('click', () => {
            const menuContent = document.getElementById('menuContent'); // Apenas o conteúdo do menu

            // Usa html2canvas para renderizar o HTML como imagem
            html2canvas(menuContent, {
                scale: 2, // Aumenta a resolução para melhor qualidade no PDF
                useCORS: true // Importante se tiver imagens de URLs externas
            }).then(canvas => {
                const imgData = canvas.toDataURL('image/png');
                const { jsPDF } = window.jspdf;
                const pdf = new jsPDF('p', 'mm', 'a4'); // 'p' para retrato, 'mm' para milímetros, 'a4' para tamanho de página

                const imgWidth = 210; // Largura do A4 em mm
                const pageHeight = 297; // Altura do A4 em mm
                const imgHeight = canvas.height * imgWidth / canvas.width;
                let heightLeft = imgHeight;//mudei dessa parte
                let position = 0;
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;
                while (heightLeft > 0) { // AQUI
                position = -heightLeft; // E AQUI
                pdf.addPage();
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight; //ate essa pater
}

                pdf.save('menu-artes-paes.pdf'); // Nome do arquivo PDF
            }).catch(error => {
                console.error("Erro ao gerar PDF:", error);
                alert("Ocorreu um erro ao gerar o PDF. Tente novamente.");
            });
        });
    }
});