let menu = document.querySelector('#menu-bar');
        let navbar = document.querySelector('.navbar');

        menu.onclick = () =>{
            menu.classList.toggle('fa-times');
            navbar.classList.toggle('active');
        }

        window.onscroll = () =>{ 
            menu.classList.remove('fa-times');
            navbar.classList.remove('active');   
        }
        
document.getElementById('peça').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça100').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça2').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça3').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça4').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça5').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça6').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça7').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça8').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça9').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça10').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça20').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça30').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça40').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça50').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça60').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça70').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça80').onclick = () => {
  window.location.href = "comprar.html";
};
document.getElementById('peça90').onclick = () => {
  window.location.href = "comprar.html";
};
